# Lux-Ventus-Blog-Community
d1 - group work
